import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Runbooks table - stores uploaded runbook documents
 */
export const runbooks = mysqlTable("runbooks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  content: text("content").notNull(),
  fileType: mysqlEnum("fileType", ["pdf", "markdown", "text"]).notNull(),
  fileKey: varchar("fileKey", { length: 255 }),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Runbook = typeof runbooks.$inferSelect;
export type InsertRunbook = typeof runbooks.$inferInsert;

/**
 * Analyses table - stores AI analysis results for runbooks
 */
export const analyses = mysqlTable("analyses", {
  id: int("id").autoincrement().primaryKey(),
  runbookId: int("runbookId").notNull(),
  healthScore: decimal("healthScore", { precision: 5, scale: 2 }).notNull(),
  actionabilityScore: decimal("actionabilityScore", { precision: 5, scale: 2 }).notNull(),
  accuracyScore: decimal("accuracyScore", { precision: 5, scale: 2 }).notNull(),
  structureScore: decimal("structureScore", { precision: 5, scale: 2 }).notNull(),
  securityScore: decimal("securityScore", { precision: 5, scale: 2 }).notNull(),
  clarityScore: decimal("clarityScore", { precision: 5, scale: 2 }).notNull(),
  analysis: text("analysis").notNull(), // JSON string with detailed analysis
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = typeof analyses.$inferInsert;

/**
 * Action items table - stores specific issues and recommendations
 */
export const actionItems = mysqlTable("actionItems", {
  id: int("id").autoincrement().primaryKey(),
  analysisId: int("analysisId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low"]).notNull(),
  category: varchar("category", { length: 64 }).notNull(), // actionability, accuracy, structure, security, clarity
  recommendation: text("recommendation").notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "resolved"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ActionItem = typeof actionItems.$inferSelect;
export type InsertActionItem = typeof actionItems.$inferInsert;

/**
 * Comparisons table - tracks improvements over time
 */
export const comparisons = mysqlTable("comparisons", {
  id: int("id").autoincrement().primaryKey(),
  runbookId: int("runbookId").notNull(),
  previousAnalysisId: int("previousAnalysisId"),
  currentAnalysisId: int("currentAnalysisId").notNull(),
  scoreImprovement: decimal("scoreImprovement", { precision: 5, scale: 2 }),
  issuesResolved: int("issuesResolved").default(0),
  newIssuesIntroduced: int("newIssuesIntroduced").default(0),
  comparedAt: timestamp("comparedAt").defaultNow().notNull(),
});

export type Comparison = typeof comparisons.$inferSelect;
export type InsertComparison = typeof comparisons.$inferInsert;

/**
 * Chat history table - stores conversations about analyses
 */
export const chatHistory = mysqlTable("chatHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  analysisId: int("analysisId").notNull(),
  messages: text("messages").notNull(), // JSON array of messages
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ChatHistory = typeof chatHistory.$inferSelect;
export type InsertChatHistory = typeof chatHistory.$inferInsert;
