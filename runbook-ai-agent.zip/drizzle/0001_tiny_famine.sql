CREATE TABLE `actionItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`analysisId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`severity` enum('critical','high','medium','low') NOT NULL,
	`category` varchar(64) NOT NULL,
	`recommendation` text NOT NULL,
	`status` enum('open','in_progress','resolved') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `actionItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`runbookId` int NOT NULL,
	`healthScore` decimal(5,2) NOT NULL,
	`actionabilityScore` decimal(5,2) NOT NULL,
	`accuracyScore` decimal(5,2) NOT NULL,
	`structureScore` decimal(5,2) NOT NULL,
	`securityScore` decimal(5,2) NOT NULL,
	`clarityScore` decimal(5,2) NOT NULL,
	`analysis` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`analysisId` int NOT NULL,
	`messages` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chatHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `comparisons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`runbookId` int NOT NULL,
	`previousAnalysisId` int,
	`currentAnalysisId` int NOT NULL,
	`scoreImprovement` decimal(5,2),
	`issuesResolved` int DEFAULT 0,
	`newIssuesIntroduced` int DEFAULT 0,
	`comparedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `comparisons_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `runbooks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`content` text NOT NULL,
	`fileType` enum('pdf','markdown','text') NOT NULL,
	`fileKey` varchar(255),
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `runbooks_id` PRIMARY KEY(`id`)
);
