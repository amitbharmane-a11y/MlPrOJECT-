# Runbook AI Agent - Architecture & Design Document

## System Overview

The Runbook AI Agent is a comprehensive platform designed to analyze IT operational documentation (runbooks) against industry best practices, provide actionable improvement recommendations, and track improvements over time. The system combines file processing, AI-powered analysis, and interactive visualization to help teams standardize and enhance their runbook quality.

## Evaluation Framework

### Scoring Criteria and Weights

The platform evaluates runbooks across five key dimensions, each with a specific weighting in the overall health score calculation:

| Criterion | Weight | Description |
| :--- | :--- | :--- |
| **Actionability** | 30% | Steps are clear, imperative, and have expected outcomes. Commands are runnable and properly formatted. |
| **Accuracy** | 25% | Commands are valid, links are not broken, content is up-to-date, and no outdated references exist. |
| **Structure** | 15% | Runbook includes prerequisites, escalation paths, rollback procedures, and proper formatting. |
| **Security** | 15% | No hardcoded credentials, API keys, or secrets. Mentions minimum required permissions. |
| **Clarity** | 15% | Content is concise, well-formatted, easy to read under pressure, and free of unnecessary jargon. |

### Health Score Calculation

The overall health score is computed as a weighted average of the five criterion scores (each scored 0-100):

```
Health Score = (Actionability × 0.30) + (Accuracy × 0.25) + (Structure × 0.15) + (Security × 0.15) + (Clarity × 0.15)
```

### Health Status Color Coding

Health scores are displayed with color-coded indicators for immediate visual feedback:

- **Red (Critical)**: Score < 60% - Runbook requires significant improvements before use
- **Yellow (Warning)**: Score 60-80% - Runbook is functional but has notable gaps
- **Green (Healthy)**: Score > 80% - Runbook meets quality standards

## Database Schema

### Core Tables

**runbooks**
- `id` (INT, PK): Unique identifier
- `userId` (INT, FK): Owner of the runbook
- `title` (VARCHAR): Runbook title
- `description` (TEXT): Brief description
- `content` (LONGTEXT): Full runbook content
- `fileType` (ENUM): pdf, markdown, text
- `uploadedAt` (TIMESTAMP): Upload timestamp
- `updatedAt` (TIMESTAMP): Last update timestamp

**analyses**
- `id` (INT, PK): Unique identifier
- `runbookId` (INT, FK): Reference to runbook
- `healthScore` (DECIMAL): Overall health score (0-100)
- `actionabilityScore` (DECIMAL): Actionability criterion score
- `accuracyScore` (DECIMAL): Accuracy criterion score
- `structureScore` (DECIMAL): Structure criterion score
- `securityScore` (DECIMAL): Security criterion score
- `clarityScore` (DECIMAL): Clarity criterion score
- `analysis` (LONGTEXT): Detailed analysis JSON
- `createdAt` (TIMESTAMP): Analysis timestamp

**actionItems**
- `id` (INT, PK): Unique identifier
- `analysisId` (INT, FK): Reference to analysis
- `title` (VARCHAR): Issue title
- `description` (TEXT): Detailed description
- `severity` (ENUM): critical, high, medium, low
- `category` (VARCHAR): Criterion category (actionability, accuracy, etc.)
- `recommendation` (TEXT): Suggested fix
- `status` (ENUM): open, in_progress, resolved
- `createdAt` (TIMESTAMP): Creation timestamp

**comparisons**
- `id` (INT, PK): Unique identifier
- `runbookId` (INT, FK): Reference to runbook
- `previousAnalysisId` (INT, FK): Earlier analysis version
- `currentAnalysisId` (INT, FK): Latest analysis version
- `scoreImprovement` (DECIMAL): Change in health score
- `comparedAt` (TIMESTAMP): Comparison timestamp

**chatHistory**
- `id` (INT, PK): Unique identifier
- `userId` (INT, FK): User who initiated chat
- `analysisId` (INT, FK): Associated analysis
- `messages` (LONGTEXT): JSON array of messages
- `createdAt` (TIMESTAMP): Conversation start
- `updatedAt` (TIMESTAMP): Last message timestamp

## AI Analysis Engine

### Evaluation Process

The AI analysis engine processes runbooks through the following stages:

1. **Content Extraction**: Parse uploaded file (PDF, Markdown, or text) and extract structured content
2. **Criterion Evaluation**: For each of the five criteria, analyze the runbook content and generate a score (0-100)
3. **Issue Detection**: Identify specific problems and categorize them by severity and criterion
4. **Recommendation Generation**: Provide actionable suggestions for each identified issue
5. **Score Aggregation**: Calculate weighted health score from individual criterion scores

### Scoring Logic Details

**Actionability (30%)**
- Presence of clear, imperative step instructions
- Expected outcomes defined for each step
- Proper command formatting and syntax highlighting
- Links to automation artifacts or scripts
- Absence of ambiguous language

**Accuracy (25%)**
- Validation of command syntax against known patterns
- Detection of broken or invalid links
- Verification that referenced files/services exist
- Checking for outdated timestamps or version references
- Consistency with current system architecture

**Structure (15%)**
- Presence of prerequisites section
- Defined escalation procedures
- Rollback/recovery steps included
- Proper heading hierarchy and formatting
- Clear section organization

**Security (15%)**
- Detection of hardcoded credentials (passwords, API keys, tokens)
- Verification that no secrets are stored in plain text
- Presence of permission/access level specifications
- Mention of least-privilege principles
- Absence of sensitive data in examples

**Clarity (15%)**
- Readability metrics (sentence length, vocabulary complexity)
- Conciseness of explanations
- Proper use of formatting (bold, lists, code blocks)
- Absence of unnecessary jargon or verbosity
- Logical flow and organization

## File Processing Pipeline

### Supported Formats

The platform accepts runbooks in three formats:

- **PDF**: Extracted using PDF parsing libraries with OCR support for scanned documents
- **Markdown**: Parsed directly to preserve structure and formatting
- **Plain Text**: Processed as raw content with basic structure inference

### Processing Steps

1. **Upload Validation**: Check file size, type, and integrity
2. **Content Extraction**: Convert file to standardized text format
3. **Preprocessing**: Clean content, normalize formatting, remove metadata
4. **Tokenization**: Break content into analyzable units
5. **Storage**: Save original file and extracted content to database

## Chatbot Interface

### Conversation Model

The chatbot maintains context across messages within an analysis session, allowing users to:

- Ask clarifying questions about specific issues
- Request deeper analysis of particular sections
- Get suggestions for improvement
- Discuss remediation strategies
- Compare multiple runbooks

### Message Types

- **Analysis Questions**: "Why did this runbook score low on accuracy?"
- **Improvement Requests**: "How can I improve the security section?"
- **Issue Clarification**: "What does this critical issue mean?"
- **Comparison Queries**: "How does this compare to my previous version?"

## Export Functionality

### PDF Export

Generates professional reports including:
- Executive summary with health score and status
- Detailed criterion breakdown with visualizations
- Action items prioritized by severity
- Recommendations and remediation steps
- Timestamp and metadata

### JSON Export

Provides structured data export including:
- Complete analysis results
- All criterion scores and details
- Full action items list
- Comparison data if available
- Metadata for integration with other systems

## Comparison Tracking

### Before/After Analysis

The platform tracks runbook improvements by:

1. Storing analysis snapshots with timestamps
2. Calculating score deltas across versions
3. Identifying resolved vs. new issues
4. Visualizing improvement trends
5. Highlighting areas of greatest improvement

### Comparison Metrics

- Overall health score change
- Individual criterion score changes
- Issues resolved count
- New issues introduced count
- Improvement percentage

## API Endpoints (tRPC Procedures)

### Runbook Management
- `runbook.upload`: Upload and store a runbook
- `runbook.list`: Retrieve user's runbooks
- `runbook.get`: Fetch specific runbook details
- `runbook.delete`: Remove a runbook

### Analysis Operations
- `analysis.create`: Trigger AI analysis on a runbook
- `analysis.get`: Retrieve analysis results
- `analysis.list`: List analyses for a runbook
- `analysis.export`: Generate export (PDF/JSON)

### Chatbot
- `chat.send`: Send message to analysis chatbot
- `chat.history`: Retrieve conversation history

### Comparisons
- `comparison.create`: Compare two analyses
- `comparison.get`: Retrieve comparison results

## Technology Stack

- **Frontend**: React 19, Tailwind CSS 4, shadcn/ui components
- **Backend**: Express 4, tRPC 11, Node.js
- **Database**: MySQL/TiDB with Drizzle ORM
- **AI/LLM**: Manus built-in LLM API for analysis and chatbot
- **File Processing**: PDF parsing, Markdown parsing libraries
- **Export**: PDF generation, JSON serialization
- **Storage**: S3 for file storage

## Security Considerations

- All file uploads validated for type and size
- Runbooks stored securely with access control
- API keys and credentials never logged or displayed
- User authentication required for all operations
- Rate limiting on analysis requests
- Input sanitization for all user-provided content
