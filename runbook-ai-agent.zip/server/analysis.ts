import { invokeLLM } from "./_core/llm";

export interface RunbookAnalysisResult {
  healthScore: number;
  actionabilityScore: number;
  accuracyScore: number;
  structureScore: number;
  securityScore: number;
  clarityScore: number;
  summary: string;
  details: {
    actionability: {
      score: number;
      findings: string[];
      issues: string[];
    };
    accuracy: {
      score: number;
      findings: string[];
      issues: string[];
    };
    structure: {
      score: number;
      findings: string[];
      issues: string[];
    };
    security: {
      score: number;
      findings: string[];
      issues: string[];
    };
    clarity: {
      score: number;
      findings: string[];
      issues: string[];
    };
  };
}

export interface ActionItem {
  title: string;
  description: string;
  severity: "critical" | "high" | "medium" | "low";
  category: string;
  recommendation: string;
}

const ANALYSIS_PROMPT = `You are an expert IT operations analyst specializing in runbook quality assessment. 

Analyze the provided runbook against these five criteria with the specified weightings:

1. **Actionability (30%)**: Are the steps clear, imperative, and actionable? Do they have expected outcomes? Are commands properly formatted and runnable?

2. **Accuracy (25%)**: Are commands valid? Are links working? Is the content up-to-date? Are there outdated references?

3. **Structure (15%)**: Does it have prerequisites, escalation paths, rollback procedures? Is it well-formatted with clear sections?

4. **Security (15%)**: Are there any hardcoded credentials, API keys, or secrets? Does it mention required permissions?

5. **Clarity (15%)**: Is it concise and easy to read? Is the language clear and free of unnecessary jargon?

For each criterion, provide:
- A score from 0-100
- Key findings (positive aspects)
- Issues found

Calculate the overall health score as:
Health Score = (Actionability × 0.30) + (Accuracy × 0.25) + (Structure × 0.15) + (Security × 0.15) + (Clarity × 0.15)

Return your analysis as a valid JSON object with the following structure:
{
  "healthScore": <number 0-100>,
  "actionabilityScore": <number 0-100>,
  "accuracyScore": <number 0-100>,
  "structureScore": <number 0-100>,
  "securityScore": <number 0-100>,
  "clarityScore": <number 0-100>,
  "summary": "<brief overall assessment>",
  "details": {
    "actionability": {
      "score": <number>,
      "findings": ["<positive finding>"],
      "issues": ["<issue found>"]
    },
    "accuracy": {
      "score": <number>,
      "findings": ["<positive finding>"],
      "issues": ["<issue found>"]
    },
    "structure": {
      "score": <number>,
      "findings": ["<positive finding>"],
      "issues": ["<issue found>"]
    },
    "security": {
      "score": <number>,
      "findings": ["<positive finding>"],
      "issues": ["<issue found>"]
    },
    "clarity": {
      "score": <number>,
      "findings": ["<positive finding>"],
      "issues": ["<issue found>"]
    }
  }
}`;

export async function analyzeRunbook(content: string): Promise<RunbookAnalysisResult> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: ANALYSIS_PROMPT,
        },
        {
          role: "user",
          content: `Please analyze this runbook:\n\n${content}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "runbook_analysis",
          strict: true,
          schema: {
            type: "object",
            properties: {
              healthScore: { type: "number" },
              actionabilityScore: { type: "number" },
              accuracyScore: { type: "number" },
              structureScore: { type: "number" },
              securityScore: { type: "number" },
              clarityScore: { type: "number" },
              summary: { type: "string" },
              details: {
                type: "object",
                properties: {
                  actionability: {
                    type: "object",
                    properties: {
                      score: { type: "number" },
                      findings: { type: "array", items: { type: "string" } },
                      issues: { type: "array", items: { type: "string" } },
                    },
                  },
                  accuracy: {
                    type: "object",
                    properties: {
                      score: { type: "number" },
                      findings: { type: "array", items: { type: "string" } },
                      issues: { type: "array", items: { type: "string" } },
                    },
                  },
                  structure: {
                    type: "object",
                    properties: {
                      score: { type: "number" },
                      findings: { type: "array", items: { type: "string" } },
                      issues: { type: "array", items: { type: "string" } },
                    },
                  },
                  security: {
                    type: "object",
                    properties: {
                      score: { type: "number" },
                      findings: { type: "array", items: { type: "string" } },
                      issues: { type: "array", items: { type: "string" } },
                    },
                  },
                  clarity: {
                    type: "object",
                    properties: {
                      score: { type: "number" },
                      findings: { type: "array", items: { type: "string" } },
                      issues: { type: "array", items: { type: "string" } },
                    },
                  },
                },
              },
            },
            required: [
              "healthScore",
              "actionabilityScore",
              "accuracyScore",
              "structureScore",
              "securityScore",
              "clarityScore",
              "summary",
              "details",
            ],
          },
        },
      },
    });

    const content_raw = response.choices[0]?.message.content;
    if (!content_raw) {
      throw new Error("No response from LLM");
    }

    const content_text = typeof content_raw === "string" ? content_raw : JSON.stringify(content_raw);
    const result = JSON.parse(content_text) as RunbookAnalysisResult;
    return result;
  } catch (error) {
    console.error("Error analyzing runbook:", error);
    throw error;
  }
}

export async function generateActionItems(analysis: RunbookAnalysisResult): Promise<ActionItem[]> {
  const items: ActionItem[] = [];

  // Helper to map score to severity
  const getSeverity = (score: number): "critical" | "high" | "medium" | "low" => {
    if (score < 40) return "critical";
    if (score < 60) return "high";
    if (score < 80) return "medium";
    return "low";
  };

  // Process each criterion
  const criteria = [
    { key: "actionability", name: "Actionability", score: analysis.actionabilityScore },
    { key: "accuracy", name: "Accuracy", score: analysis.accuracyScore },
    { key: "structure", name: "Structure", score: analysis.structureScore },
    { key: "security", name: "Security", score: analysis.securityScore },
    { key: "clarity", name: "Clarity", score: analysis.clarityScore },
  ];

  for (const criterion of criteria) {
    const details = analysis.details[criterion.key as keyof typeof analysis.details];
    
    // Create action item for each issue
    for (const issue of details.issues) {
      items.push({
        title: `${criterion.name}: ${issue.substring(0, 50)}${issue.length > 50 ? "..." : ""}`,
        description: issue,
        severity: getSeverity(details.score),
        category: criterion.key,
        recommendation: `Review and improve ${criterion.name.toLowerCase()} aspect of the runbook. Current score: ${details.score}/100`,
      });
    }
  }

  // Sort by severity
  const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  items.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);

  return items;
}

export async function generateChatbotResponse(
  query: string,
  analysis: RunbookAnalysisResult,
  actionItems: ActionItem[]
): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a helpful assistant for runbook analysis. You have access to the following analysis data:

Health Score: ${analysis.healthScore}/100
- Actionability: ${analysis.actionabilityScore}/100
- Accuracy: ${analysis.accuracyScore}/100
- Structure: ${analysis.structureScore}/100
- Security: ${analysis.securityScore}/100
- Clarity: ${analysis.clarityScore}/100

Summary: ${analysis.summary}

Action Items:
${actionItems.map((item) => `- [${item.severity.toUpperCase()}] ${item.title}: ${item.recommendation}`).join("\n")}

Answer questions about the runbook analysis in a helpful, concise manner.`,
        },
        {
          role: "user",
          content: query,
        },
      ],
    });

    const content_raw = response.choices[0]?.message.content;
    const content_text = typeof content_raw === "string" ? content_raw : JSON.stringify(content_raw);
    return content_text || "Unable to generate response";
  } catch (error) {
    console.error("Error generating chatbot response:", error);
    throw error;
  }
}
