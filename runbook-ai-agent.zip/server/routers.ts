import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  runbook: router({
    upload: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        content: z.string().min(1),
        fileType: z.enum(["pdf", "markdown", "text"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const { createRunbook } = await import("./db");
        const result = await createRunbook({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          content: input.content,
          fileType: input.fileType,
        });
        return result;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      const { getRunbooksByUserId } = await import("./db");
      return getRunbooksByUserId(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const { getRunbookById } = await import("./db");
        return getRunbookById(input.id);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const { deleteRunbook } = await import("./db");
        return deleteRunbook(input.id);
      }),
  }),

  analysis: router({
    create: protectedProcedure
      .input(z.object({ runbookId: z.number() }))
      .mutation(async ({ input }) => {
        const { getRunbookById, createAnalysis, createActionItem } = await import("./db");
        const { analyzeRunbook, generateActionItems } = await import("./analysis");

        const runbook = await getRunbookById(input.runbookId);
        if (!runbook) throw new TRPCError({ code: "NOT_FOUND" });

        const analysisResult = await analyzeRunbook(runbook.content);
        const analysis = await createAnalysis({
          runbookId: input.runbookId,
          healthScore: analysisResult.healthScore as any,
          actionabilityScore: analysisResult.actionabilityScore as any,
          accuracyScore: analysisResult.accuracyScore as any,
          structureScore: analysisResult.structureScore as any,
          securityScore: analysisResult.securityScore as any,
          clarityScore: analysisResult.clarityScore as any,
          analysis: JSON.stringify(analysisResult),
        });

        const analysisId = (analysis as any).insertId || 0;
        const actionItems = await generateActionItems(analysisResult);
        for (const item of actionItems) {
          await createActionItem({
            analysisId,
            title: item.title,
            description: item.description,
            severity: item.severity,
            category: item.category,
            recommendation: item.recommendation,
          });
        }

        return { analysisId, ...analysisResult };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const { getAnalysisById, getActionItemsByAnalysisId } = await import("./db");
        const analysis = await getAnalysisById(input.id);
        if (!analysis) throw new TRPCError({ code: "NOT_FOUND" });

        const actionItems = await getActionItemsByAnalysisId(input.id);
        return { ...analysis, actionItems };
      }),

    list: protectedProcedure
      .input(z.object({ runbookId: z.number() }))
      .query(async ({ input }) => {
        const { getAnalysisByRunbookId } = await import("./db");
        return getAnalysisByRunbookId(input.runbookId);
      }),
  }),

  chat: router({
    send: protectedProcedure
      .input(z.object({
        analysisId: z.number(),
        message: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const { getAnalysisById, getChatHistoryByAnalysisId, createChatHistory, updateChatHistory, getActionItemsByAnalysisId } = await import("./db");
        const { generateChatbotResponse } = await import("./analysis");

        const analysis = await getAnalysisById(input.analysisId);
        if (!analysis) throw new TRPCError({ code: "NOT_FOUND" });

        const actionItems = await getActionItemsByAnalysisId(input.analysisId);
        const analysisData = JSON.parse(analysis.analysis);
        const response = await generateChatbotResponse(input.message, analysisData, actionItems);

        let chatHistory = await getChatHistoryByAnalysisId(input.analysisId);
        const messages = chatHistory ? JSON.parse(chatHistory.messages) : [];
        messages.push({ role: "user", content: input.message });
        messages.push({ role: "assistant", content: response });

        if (chatHistory) {
          await updateChatHistory(chatHistory.id, JSON.stringify(messages));
        } else {
          await createChatHistory({
            userId: ctx.user.id,
            analysisId: input.analysisId,
            messages: JSON.stringify(messages),
          });
        }

        return { response, messages };
      }),

    history: protectedProcedure
      .input(z.object({ analysisId: z.number() }))
      .query(async ({ input }) => {
        const { getChatHistoryByAnalysisId } = await import("./db");
        const chatHistory = await getChatHistoryByAnalysisId(input.analysisId);
        if (!chatHistory) return { messages: [] };
        return { messages: JSON.parse(chatHistory.messages) };
      }),
  }),
});

export type AppRouter = typeof appRouter;
