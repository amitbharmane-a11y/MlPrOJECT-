import { storagePut } from "./storage";

export interface ParsedFile {
  content: string;
  title: string;
  fileType: "pdf" | "markdown" | "text";
}

/**
 * Extract text from PDF using a simple approach
 * For production, consider using pdf-parse or similar library
 */
async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  // For now, return a placeholder
  // In production, use pdf-parse or similar
  try {
    // This is a simplified version - in production you'd use pdf-parse
    const text = buffer.toString("utf-8").replace(/[^\x20-\x7E\n]/g, "");
    return text || "Unable to extract text from PDF";
  } catch (error) {
    console.error("Error extracting PDF text:", error);
    throw new Error("Failed to extract text from PDF");
  }
}

/**
 * Parse Markdown file content
 */
function parseMarkdown(content: string): string {
  // Markdown is already text, just return it
  return content;
}

/**
 * Parse plain text file
 */
function parseText(content: string): string {
  return content;
}

/**
 * Process uploaded file and extract content
 */
export async function processUploadedFile(
  buffer: Buffer,
  filename: string,
  fileType: "pdf" | "markdown" | "text"
): Promise<ParsedFile> {
  let content = "";
  let title = filename.replace(/\.[^/.]+$/, ""); // Remove file extension

  try {
    if (fileType === "pdf") {
      content = await extractTextFromPDF(buffer);
    } else if (fileType === "markdown") {
      content = parseMarkdown(buffer.toString("utf-8"));
    } else if (fileType === "text") {
      content = parseText(buffer.toString("utf-8"));
    } else {
      throw new Error(`Unsupported file type: ${fileType}`);
    }

    if (!content || content.trim().length === 0) {
      throw new Error("File content is empty");
    }

    return {
      content: content.trim(),
      title,
      fileType,
    };
  } catch (error) {
    console.error("Error processing file:", error);
    throw error;
  }
}

/**
 * Store file in S3 and return the key
 */
export async function storeFile(
  buffer: Buffer,
  filename: string,
  userId: number
): Promise<string> {
  try {
    const timestamp = Date.now();
    const sanitizedFilename = filename.replace(/[^a-zA-Z0-9.-]/g, "_");
    const fileKey = `runbooks/${userId}/${timestamp}-${sanitizedFilename}`;

    const { key } = await storagePut(fileKey, buffer, "application/octet-stream");
    return key;
  } catch (error) {
    console.error("Error storing file:", error);
    throw new Error("Failed to store file");
  }
}

/**
 * Detect file type from filename
 */
export function detectFileType(filename: string): "pdf" | "markdown" | "text" | null {
  const ext = filename.split(".").pop()?.toLowerCase();

  if (ext === "pdf") return "pdf";
  if (ext === "md" || ext === "markdown") return "markdown";
  if (ext === "txt" || ext === "text") return "text";

  return null;
}

/**
 * Validate file size (max 10MB)
 */
export function validateFileSize(buffer: Buffer, maxSizeMB: number = 10): boolean {
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  return buffer.length <= maxSizeBytes;
}
