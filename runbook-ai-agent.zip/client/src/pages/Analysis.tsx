import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation, useRoute } from "wouter";
import { AlertCircle, CheckCircle, TrendingUp, Download } from "lucide-react";
import { useState } from "react";

export default function Analysis() {
  const [, setLocation] = useLocation();
  const [route, params] = useRoute("/analysis/:id");
  const analysisId = params?.id ? parseInt(params.id) : null;
  const [expandedItem, setExpandedItem] = useState<number | null>(null);

  const analysisQuery = trpc.analysis.get.useQuery(
    { id: analysisId || 0 },
    { enabled: !!analysisId }
  );

  if (!analysisId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-slate-600">Analysis not found</p>
          <Button onClick={() => setLocation("/dashboard")} className="mt-4">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if (analysisQuery.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading analysis...</p>
        </div>
      </div>
    );
  }

  const analysis = analysisQuery.data;
  if (!analysis) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-slate-600">Analysis not found</p>
          <Button onClick={() => setLocation("/dashboard")} className="mt-4">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-50 border-red-200 text-red-900";
      case "high":
        return "bg-orange-50 border-orange-200 text-orange-900";
      case "medium":
        return "bg-yellow-50 border-yellow-200 text-yellow-900";
      case "low":
        return "bg-blue-50 border-blue-200 text-blue-900";
      default:
        return "bg-slate-50 border-slate-200 text-slate-900";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return "text-red-600";
      case "high":
        return "text-orange-600";
      case "medium":
        return "text-yellow-600";
      case "low":
        return "text-blue-600";
      default:
        return "text-slate-600";
    }
  };

  const actionItems = analysis.actionItems || [];
  const criticalCount = actionItems.filter((item: any) => item.severity === "critical").length;
  const highCount = actionItems.filter((item: any) => item.severity === "high").length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Button
            variant="outline"
            onClick={() => setLocation("/dashboard")}
            className="mb-4"
          >
            ← Back
          </Button>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Analysis Details
          </h1>
          <p className="text-lg text-slate-600">
            Detailed breakdown and action items
          </p>
        </div>

        {/* Summary Card */}
        <div className="bg-white rounded-lg shadow-md p-8 border border-slate-200 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="text-center">
              <p className="text-slate-600 font-medium mb-2">Overall Health</p>
              <p className="text-4xl font-bold text-blue-600">
                {Math.round(Number(analysis.healthScore))}
              </p>
              <p className="text-sm text-slate-600">/100</p>
            </div>
            <div className="text-center">
              <p className="text-slate-600 font-medium mb-2">Critical Issues</p>
              <p className="text-4xl font-bold text-red-600">{criticalCount}</p>
            </div>
            <div className="text-center">
              <p className="text-slate-600 font-medium mb-2">High Priority</p>
              <p className="text-4xl font-bold text-orange-600">{highCount}</p>
            </div>
          </div>

          <div className="flex gap-4">
            <Button
              onClick={() => setLocation(`/chat/${analysisId}`)}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            >
              Ask AI Questions
            </Button>
            <Button variant="outline" className="flex-1">
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Criterion Breakdown */}
        <div className="bg-white rounded-lg shadow-md p-8 border border-slate-200 mb-6">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Criterion Scores
          </h2>

          <div className="space-y-4">
            {[
              { name: "Actionability", score: analysis.actionabilityScore, weight: "30%" },
              { name: "Accuracy", score: analysis.accuracyScore, weight: "25%" },
              { name: "Structure", score: analysis.structureScore, weight: "15%" },
              { name: "Security", score: analysis.securityScore, weight: "15%" },
              { name: "Clarity", score: analysis.clarityScore, weight: "15%" },
            ].map((criterion) => (
              <div key={criterion.name} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold text-slate-900">{criterion.name}</h3>
                  <span className="text-sm text-slate-600">{criterion.weight}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl font-bold text-slate-900">
                    {Math.round(Number(criterion.score))}
                  </span>
                  <div className="flex-1 bg-slate-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full bg-blue-600 transition-all"
                      style={{ width: `${Number(criterion.score)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Items */}
        <div className="bg-white rounded-lg shadow-md p-8 border border-slate-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">
            Action Items ({actionItems.length})
          </h2>

          {actionItems.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
              <p className="text-slate-600">
                No action items found. This runbook is in great shape!
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {actionItems.map((item: any, index: number) => (
                <div
                  key={index}
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${getSeverityColor(item.severity)}`}
                  onClick={() => setExpandedItem(expandedItem === index ? null : index)}
                >
                  <div className="flex items-start gap-3">
                    <AlertCircle className={`w-5 h-5 mt-1 flex-shrink-0 ${getSeverityIcon(item.severity)}`} />
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-semibold">{item.title}</h4>
                        <span className="text-xs font-medium px-2 py-1 bg-white bg-opacity-50 rounded">
                          {item.severity.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm opacity-75">{item.description}</p>

                      {expandedItem === index && (
                        <div className="mt-4 pt-4 border-t border-current border-opacity-20">
                          <p className="text-sm font-semibold mb-2">Recommendation:</p>
                          <p className="text-sm opacity-90">{item.recommendation}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
