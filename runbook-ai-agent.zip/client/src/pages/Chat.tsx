import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLocation, useRoute } from "wouter";
import { Send, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

export default function Chat() {
  const [, setLocation] = useLocation();
  const [route, params] = useRoute("/chat/:id");
  const analysisId = params?.id ? parseInt(params.id) : null;
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const historyQuery = trpc.chat.history.useQuery(
    { analysisId: analysisId || 0 },
    { enabled: !!analysisId }
  );
  const sendMutation = trpc.chat.send.useMutation();

  const messages = historyQuery.data?.messages || [];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!message.trim() || !analysisId) {
      toast.error("Please enter a message");
      return;
    }

    const userMessage = message;
    setMessage("");
    setIsLoading(true);

    try {
      const result = await sendMutation.mutateAsync({
        analysisId,
        message: userMessage,
      });

      historyQuery.refetch();
    } catch (error) {
      console.error("Chat error:", error);
      toast.error("Failed to send message");
      setMessage(userMessage);
    } finally {
      setIsLoading(false);
    }
  };

  if (!analysisId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-slate-600">Analysis not found</p>
          <Button onClick={() => setLocation("/dashboard")} className="mt-4">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4 flex flex-col">
      <div className="max-w-4xl mx-auto w-full flex flex-col h-screen">
        <div className="mb-6">
          <Button
            variant="outline"
            onClick={() => setLocation("/dashboard")}
            className="mb-4"
          >
            ← Back
          </Button>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Runbook Analysis Chat
          </h1>
          <p className="text-lg text-slate-600">
            Ask questions about your runbook analysis
          </p>
        </div>

        {/* Chat Container */}
        <div className="bg-white rounded-lg shadow-md border border-slate-200 flex-1 flex flex-col mb-6">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <MessageCircle className="w-16 h-16 text-slate-400 mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  Start a Conversation
                </h3>
                <p className="text-slate-600 max-w-md">
                  Ask me questions about your runbook analysis, improvement suggestions, or specific issues you'd like to discuss.
                </p>
              </div>
            ) : (
              <>
                {messages.map((msg: any, index: number) => (
                  <div
                    key={index}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-blue-600 text-white rounded-br-none"
                          : "bg-slate-100 text-slate-900 rounded-bl-none"
                      }`}
                    >
                      {msg.role === "assistant" ? (
                        <Streamdown>{msg.content}</Streamdown>
                      ) : (
                        <p className="text-sm">{msg.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input Area */}
          <div className="border-t border-slate-200 p-6">
            <form onSubmit={handleSend} className="flex gap-3">
              <Input
                type="text"
                placeholder="Ask a question about your runbook..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                disabled={isLoading}
                className="flex-1"
              />
              <Button
                type="submit"
                disabled={isLoading || !message.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-md border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-900 mb-4">Suggested Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <button
              onClick={() => setMessage("What are the most critical issues I should fix first?")}
              className="text-left p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-colors"
            >
              <p className="text-sm font-medium text-slate-900">
                What are the most critical issues?
              </p>
            </button>
            <button
              onClick={() => setMessage("How can I improve the security section of my runbook?")}
              className="text-left p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-colors"
            >
              <p className="text-sm font-medium text-slate-900">
                How can I improve security?
              </p>
            </button>
            <button
              onClick={() => setMessage("What does the accuracy score mean and how can I improve it?")}
              className="text-left p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-colors"
            >
              <p className="text-sm font-medium text-slate-900">
                How to improve accuracy?
              </p>
            </button>
            <button
              onClick={() => setMessage("Can you explain the action items and their priority?")}
              className="text-left p-3 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-colors"
            >
              <p className="text-sm font-medium text-slate-900">
                Explain action items
              </p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
