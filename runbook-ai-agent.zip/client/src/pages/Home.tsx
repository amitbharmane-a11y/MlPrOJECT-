import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { FileUp, BarChart3, MessageSquare } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-md w-full mx-auto px-6 py-12 bg-white rounded-lg shadow-lg">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-lg mb-4">
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Runbook AI Agent</h1>
            <p className="text-slate-600">Analyze and improve your operational documentation</p>
          </div>

          <div className="space-y-4 mb-8">
            <div className="flex items-start gap-3">
              <FileUp className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900">Upload Runbooks</h3>
                <p className="text-sm text-slate-600">Support for PDF, Markdown, and text formats</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <BarChart3 className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900">AI Analysis</h3>
                <p className="text-sm text-slate-600">Get health scores and improvement recommendations</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MessageSquare className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-slate-900">Interactive Chat</h3>
                <p className="text-sm text-slate-600">Ask questions about your runbook analysis</p>
              </div>
            </div>
          </div>

          <a href={getLoginUrl()}>
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Sign in to Get Started
            </Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Welcome, {user?.name || "User"}!</h1>
          <p className="text-lg text-slate-600">Analyze and improve your IT runbooks with AI-powered insights</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <button
            onClick={() => setLocation("/upload")}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-8 text-left border border-slate-200 hover:border-blue-300"
          >
            <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg mb-4">
              <FileUp className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Upload Runbook</h3>
            <p className="text-slate-600">Upload a new runbook for analysis</p>
          </button>

          <button
            onClick={() => setLocation("/dashboard")}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-8 text-left border border-slate-200 hover:border-blue-300"
          >
            <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
              <BarChart3 className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">View Dashboard</h3>
            <p className="text-slate-600">See all your runbook analyses</p>
          </button>

          <button
            onClick={() => setLocation("/history")}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-8 text-left border border-slate-200 hover:border-blue-300"
          >
            <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-lg mb-4">
              <MessageSquare className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">Recent Analyses</h3>
            <p className="text-slate-600">View your analysis history</p>
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-md p-8 border border-slate-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full mb-3 text-blue-600 font-semibold">1</div>
              <h4 className="font-semibold text-slate-900 mb-2">Upload</h4>
              <p className="text-sm text-slate-600">Upload your runbook in PDF, Markdown, or text format</p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full mb-3 text-blue-600 font-semibold">2</div>
              <h4 className="font-semibold text-slate-900 mb-2">Analyze</h4>
              <p className="text-sm text-slate-600">AI evaluates against 5 key criteria with detailed scoring</p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full mb-3 text-blue-600 font-semibold">3</div>
              <h4 className="font-semibold text-slate-900 mb-2">Review</h4>
              <p className="text-sm text-slate-600">Get health score and actionable improvement items</p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full mb-3 text-blue-600 font-semibold">4</div>
              <h4 className="font-semibold text-slate-900 mb-2">Improve</h4>
              <p className="text-sm text-slate-600">Chat with AI and track improvements over time</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
