import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { BarChart3, AlertCircle, CheckCircle, TrendingUp } from "lucide-react";
import { toast } from "sonner";

interface HealthScore {
  score: number;
  status: "critical" | "warning" | "healthy";
  color: string;
  bgColor: string;
}

function getHealthScore(score: number): HealthScore {
  if (score < 60) {
    return {
      score,
      status: "critical",
      color: "text-red-600",
      bgColor: "bg-red-50",
    };
  } else if (score < 80) {
    return {
      score,
      status: "warning",
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
    };
  } else {
    return {
      score,
      status: "healthy",
      color: "text-green-600",
      bgColor: "bg-green-50",
    };
  }
}

function ScoreCard({
  label,
  score,
  weight,
}: {
  label: string;
  score: number;
  weight: string;
}) {
  const health = getHealthScore(score);
  return (
    <div className={`p-4 rounded-lg border ${health.bgColor}`}>
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-semibold text-slate-900">{label}</h4>
        <span className="text-xs font-medium text-slate-600">{weight}</span>
      </div>
      <div className="flex items-end gap-2">
        <span className={`text-3xl font-bold ${health.color}`}>{score}</span>
        <span className="text-slate-600 mb-1">/100</span>
      </div>
      <div className="mt-3 w-full bg-slate-200 rounded-full h-2">
        <div
          className={`h-2 rounded-full transition-all ${health.color.replace("text-", "bg-")}`}
          style={{ width: `${score}%` }}
        ></div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [selectedRunbook, setSelectedRunbook] = useState<number | null>(null);

  const runbooksQuery = trpc.runbook.list.useQuery();
  const analysisQuery = trpc.analysis.list.useQuery(
    { runbookId: selectedRunbook || 0 },
    { enabled: !!selectedRunbook }
  );
  const analysisMutation = trpc.analysis.create.useMutation();

  const runbooks = runbooksQuery.data || [];
  const analyses = analysisQuery.data || [];
  const latestAnalysis = analyses[0];

  useEffect(() => {
    if (runbooks.length > 0 && !selectedRunbook) {
      setSelectedRunbook(runbooks[0].id);
    }
  }, [runbooks, selectedRunbook]);

  const handleAnalyze = async () => {
    if (!selectedRunbook) {
      toast.error("Please select a runbook");
      return;
    }

    try {
      await analysisMutation.mutateAsync({ runbookId: selectedRunbook });
      toast.success("Analysis started!");
      analysisQuery.refetch();
    } catch (error) {
      console.error("Analysis error:", error);
      toast.error("Failed to start analysis");
    }
  };

  if (runbooksQuery.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-slate-600">Loading runbooks...</p>
          </div>
        </div>
      </div>
    );
  }

  if (runbooks.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <Button
              variant="outline"
              onClick={() => setLocation("/")}
              className="mb-4"
            >
              ← Back
            </Button>
            <h1 className="text-4xl font-bold text-slate-900 mb-2">Dashboard</h1>
            <p className="text-lg text-slate-600">
              No runbooks yet. Upload one to get started.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-12 border border-slate-200 text-center">
            <BarChart3 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              No Runbooks Found
            </h2>
            <p className="text-slate-600 mb-6">
              Start by uploading your first runbook for analysis
            </p>
            <Button
              onClick={() => setLocation("/upload")}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Upload Runbook
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button
            variant="outline"
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            ← Back
          </Button>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Dashboard</h1>
          <p className="text-lg text-slate-600">
            Analyze and track your runbook health
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Runbook Selector */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 border border-slate-200 h-full">
              <h3 className="font-semibold text-slate-900 mb-4">Runbooks</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {runbooks.map((runbook) => (
                  <button
                    key={runbook.id}
                    onClick={() => setSelectedRunbook(runbook.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedRunbook === runbook.id
                        ? "bg-blue-50 border-blue-300"
                        : "bg-slate-50 border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <p className="font-medium text-slate-900 truncate">
                      {runbook.title}
                    </p>
                    <p className="text-xs text-slate-600 truncate">
                      {runbook.description || "No description"}
                    </p>
                  </button>
                ))}
              </div>

              <Button
                onClick={() => setLocation("/upload")}
                variant="outline"
                className="w-full mt-4"
              >
                + Upload New
              </Button>
            </div>
          </div>

          {/* Analysis Results */}
          <div className="lg:col-span-3">
            {latestAnalysis ? (
              <div className="bg-white rounded-lg shadow-md p-8 border border-slate-200">
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-2xl font-bold text-slate-900">
                      Health Score
                    </h2>
                    <Button
                      onClick={handleAnalyze}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Re-analyze
                    </Button>
                  </div>

                  {/* Overall Health Score */}
                  <div className={`p-6 rounded-lg border mb-6 ${getHealthScore(Number(latestAnalysis.healthScore)).bgColor}`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-slate-600 font-medium mb-2">
                          Overall Health
                        </p>
                        <div className="flex items-baseline gap-2">
                          <span className={`text-5xl font-bold ${getHealthScore(Number(latestAnalysis.healthScore)).color}`}>
                            {Math.round(Number(latestAnalysis.healthScore))}
                          </span>
                          <span className="text-slate-600">/100</span>
                        </div>
                      </div>
                      <div className="text-right">
                        {getHealthScore(Number(latestAnalysis.healthScore)).status === "healthy" && (
                          <CheckCircle className="w-12 h-12 text-green-600" />
                        )}
                        {getHealthScore(Number(latestAnalysis.healthScore)).status === "warning" && (
                          <AlertCircle className="w-12 h-12 text-yellow-600" />
                        )}
                        {getHealthScore(Number(latestAnalysis.healthScore)).status === "critical" && (
                          <AlertCircle className="w-12 h-12 text-red-600" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Criterion Scores */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <ScoreCard
                      label="Actionability"
                      score={Math.round(Number(latestAnalysis.actionabilityScore))}
                      weight="30%"
                    />
                    <ScoreCard
                      label="Accuracy"
                      score={Math.round(Number(latestAnalysis.accuracyScore))}
                      weight="25%"
                    />
                    <ScoreCard
                      label="Structure"
                      score={Math.round(Number(latestAnalysis.structureScore))}
                      weight="15%"
                    />
                    <ScoreCard
                      label="Security"
                      score={Math.round(Number(latestAnalysis.securityScore))}
                      weight="15%"
                    />
                    <ScoreCard
                      label="Clarity"
                      score={Math.round(Number(latestAnalysis.clarityScore))}
                      weight="15%"
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    onClick={() => setLocation(`/analysis/${latestAnalysis.id}`)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    View Details
                  </Button>
                  <Button
                    onClick={() => setLocation(`/chat/${latestAnalysis.id}`)}
                    variant="outline"
                    className="flex-1"
                  >
                    Ask AI
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-12 border border-slate-200 text-center">
                <TrendingUp className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-slate-900 mb-2">
                  No Analysis Yet
                </h3>
                <p className="text-slate-600 mb-6">
                  Analyze this runbook to get health scores and recommendations
                </p>
                <Button
                  onClick={handleAnalyze}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Start Analysis
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
